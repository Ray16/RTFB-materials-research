# Redox polymer manuscript

Main document: `main.tex`. Supporting Information: `supporting_information.tex`. Compiler: pdfLaTeX.

This is a working draft with explicit unfinished analyses. Figures, bibliography and frozen numerical TeX inputs are included.

The source and frozen computational evidence are maintained in the 0_redox project. Do not replace collaborators' edits with a fresh export: fetch and merge before each edit and push.
