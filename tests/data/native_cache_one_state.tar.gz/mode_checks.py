import math
import numpy as np


def spin_valid(point):
    value = point['spin'].get('spin_contam', math.inf)
    return type(value) in (float, int) and math.isfinite(value) and abs(value) <= .1


def projected_modes(matrix, xyz, mass):
    """Independent rigid-space removal used in the original scientific audit."""
    centered = xyz - np.average(xyz, axis=0, weights=mass)
    vectors = [(np.sqrt(mass)[:, None]*axis).ravel() for axis in np.eye(3)]
    vectors += [(np.sqrt(mass)[:, None]*np.cross(centered, axis)).ravel() for axis in np.eye(3)]
    rigid = []
    for vector in vectors:
        residual = vector.copy()
        for _ in range(2):
            for unit in rigid:
                residual -= unit*np.dot(unit, residual)
        if np.linalg.norm(residual) > 1e-10*max(1., np.linalg.norm(vector)):
            rigid.append(residual/np.linalg.norm(residual))
    basis = np.array(rigid).T
    values, vectors = np.linalg.eigh(np.eye(matrix.shape[0])-basis@basis.T)
    internal = vectors[:, values > .5]
    roots = np.repeat(np.sqrt(mass*(1.660539040e-27/9.10938356e-31)), 3)
    weighted = (matrix+matrix.T)/(2*np.outer(roots, roots))
    values = np.linalg.eigvalsh(internal.T@weighted@internal)
    return np.sign(values)*np.sqrt(abs(values))*219474.63067, len(rigid)


def finite_difference_checks(raw, native, matrix, gradient, symbols, coords, method, read_json):
    hetero = next((i for i, symbol in enumerate(symbols) if symbol == 'O'),
                  next((i for i, symbol in enumerate(symbols) if symbol == 'Fe'), len(symbols)-1))
    required = {(0, 1), (hetero, 2)}
    required.update(tuple(map(int, np.unravel_index(i, gradient.shape)))
                    for i in np.argsort(abs(gradient).ravel())[-2:])
    if {tuple(v) for v in native['required_columns']} != required:
        raise ValueError('Hessian-column coverage differs')
    baseline = read_json(raw/'SCF_evaluations/0000/evaluation.json')
    if (not baseline['SCF_converged'] or not spin_valid(baseline)
            or baseline['experimental_method_id'] != method
            or not np.allclose(baseline['coordinates_Bohr'], coords, rtol=0, atol=1e-10)
            or not np.allclose(baseline['gradient_Ha_Bohr'], gradient, rtol=0, atol=1e-13)):
        raise ValueError('Baseline SCF/gradient/geometry binding differs')
    index, checks = 1, []
    for atom, axis in sorted(required):
        for step in (.0005, .001):
            points = [read_json(raw/f'SCF_evaluations/{i:04d}/evaluation.json') for i in (index, index+1)]
            index += 2
            vectors = []
            for sign, point in zip((-1, 1), points):
                expected = coords.copy()
                expected[atom, axis] += sign*step
                vector = np.asarray(point['gradient_Ha_Bohr'], dtype=float)
                if (vector.shape != gradient.shape or not np.isfinite(vector).all()
                        or not np.allclose(point['coordinates_Bohr'], expected, rtol=0, atol=1e-12)
                        or not point['SCF_converged'] or not spin_valid(point)
                        or point['experimental_method_id'] != method):
                    raise ValueError('Displaced SCF/gradient/model binding differs')
                vectors.append(vector)
            finite = (vectors[1]-vectors[0]).ravel()/(2*step)
            error = float(np.linalg.norm(finite-matrix[:, 3*atom+axis])/max(np.linalg.norm(finite), 1e-14))
            stored = next(v for v in native['derivative_checks']
                          if (v['atom'], v['axis'], v['step_Bohr']) == (atom, axis, step))
            if (not math.isfinite(error) or not math.isfinite(stored['relative_error'])
                    or error > .01 or abs(error-stored['relative_error']) > 1e-10):
                raise ValueError('Sampled Hessian derivative check differs or fails')
            checks.append(error)
    return checks, required, index
