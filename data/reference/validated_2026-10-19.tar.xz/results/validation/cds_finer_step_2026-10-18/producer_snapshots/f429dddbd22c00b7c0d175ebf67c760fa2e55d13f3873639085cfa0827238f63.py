"""One reserved worker executes the three declared isolated qualification cases."""
import argparse,gc,json,os,runpy,socket,time
from pathlib import Path
from redox.core.io import atomic_write_json
from redox.workflows.resources import verify_gate_owner

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--manifest',required=True,type=Path);parser.add_argument('--tasks',required=True);parser.add_argument('--name',required=True);a=parser.parse_args()
 verify_gate_owner();plan=json.loads(a.manifest.read_text());run=a.manifest.parent
 indices=[int(i) for i in a.tasks.split(',')];assert len(indices)==len(set(indices)) and all(0<=i<len(plan['tasks']) for i in indices)
 status=dict(indices=indices,status='running',host=socket.gethostname(),pid=os.getpid(),process_start=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],cpu_affinity=sorted(os.sched_getaffinity(0)),tasks=[],started=time.time(),production_admission=False)
 atomic_write_json(run/f'batch_status_{a.name}.json',status)
 failures=0
 for i in indices:
  t=plan['tasks'][i]
  import sys
  sys.argv=[str(run/'qualify.py'),'--manifest',str(a.manifest),'--task',str(i)]
  entry=dict(key=t['key'],status='running',started=time.time());status['tasks'].append(entry);atomic_write_json(run/f'batch_status_{a.name}.json',status)
  try:
   runpy.run_path(str(run/'qualify.py'),run_name='__main__')
   result=json.loads((run/t['key']/'status.json').read_text())
   if result['status'] not in ('isolated_control_verified','isolated_target_verified'):raise RuntimeError('Qualification output not verified')
   entry['status']=result['status'];failures=0
  except Exception as exc:entry.update(status='failed_preserved',error=repr(exc));failures+=1
  finally:
   gc.collect()
   from redox.qm.dft import _free_gpu_pool
   _free_gpu_pool()
   entry['finished']=time.time();atomic_write_json(run/f'batch_status_{a.name}.json',status)
  if failures>=3:break
 status.update(status='isolated_cases_verified' if len(status['tasks'])==len(indices) and all(x['status'].startswith('isolated_') for x in status['tasks']) else 'incomplete_preserved',finished=time.time());atomic_write_json(run/f'batch_status_{a.name}.json',status)
 if status['status']!='isolated_cases_verified':raise SystemExit(1)
if __name__=='__main__':main()
