"""Independent review of isolated finer-CDS matrices and saved gradient evidence.

Read-only unless --seal is requested after every declared case passes. This does
not edit the production loader, adopt a target or overwrite an older certificate.
"""
import argparse,hashlib,json,math,os,re,time
from pathlib import Path
for key in ('OMP_NUM_THREADS','OMP_THREAD_LIMIT','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[key]='2'
import numpy as np
from ase.io import read
from pyscf import gto
from pyscf.hessian import thermo
from redox.core.common import ROOT
from redox.core.io import atomic_write_json
from redox.workflows.resources import allocation_guard,cpu_allocation,host_capacity

BASE=Path(__file__).resolve().parent
HA_EV=27.211386245988

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--seal',action='store_true');ap.add_argument('--replacement-case',type=Path);a=ap.parse_args()
 with allocation_guard():
  host_capacity(2);cpus=cpu_allocation(2);os.sched_setaffinity(0,cpus)
 plan=json.loads((BASE/'plan.json').read_text());checks=[];cases=[];controls=[];pending=[];evidence={}
 def check(label,ok,detail=None):checks.append(dict(label=label,passed=bool(ok),detail=detail))
 archive=json.loads((BASE/'archived_producer_paths.json').read_text())
 for path,digest in plan['producer_sha256'].items():
  snapshot=(ROOT/Path(archive[path])).resolve();check('producer_snapshot:'+path,sha(snapshot)==digest);evidence[str(snapshot.relative_to(ROOT))]=digest
 tasks=list(plan['tasks']);case_paths={};exclusions=[]
 if a.replacement_case:
  replacement=a.replacement_case.resolve();rr=json.loads(replacement.read_text());original=next(t for t in tasks if not t['control']);old=json.loads((BASE/original['key']/'status.json').read_text())
  assert old['status']=='failed_preserved' and 'not a minimum' in old['error']
  assert all(rr['task'][k]==original[k] for k in ('id','state','charge','mult')) and rr['status']=='isolated_target_verified'
  branch=Path(rr['task']['source']);owner=json.loads((branch/'validation_status.json').read_text());assert owner['status']=='private_minimum_and_energy_verified_pending_certificate' and not owner['canonical_modified'] and not owner['production_admission']
  recovery=json.loads((branch/'convergence_recovery.json').read_text());assert recovery['explicit_converged_state'] and recovery['all_five_criteria_passed'] and recovery['trajectory_maximum_coordinate_difference_A']<1e-6
  capture=json.loads(Path(recovery['source_capture']).read_text());assert capture['state']==capture['CONVERGED_state'] and all(capture['values'][k]<v for k,v in capture['limits'].items())
  from pyscf.data.nist import BOHR
  atoms=read(branch/'opt.xyz');assert np.max(abs(atoms.positions-np.asarray(capture['final_coordinates_Bohr'])*BOHR))<1e-6
  original_source=json.loads((branch.parent/'source.json').read_text());assert original_source['source_state_dir']==original['source'] and original_source['id']==original['id']
  for path,digest in original_source['inputs_sha256'].items():assert sha(path)==digest
  for path,digest in recovery['evidence_sha256'].items():assert sha(path)==digest
  from redox.core.common import smiles_to_xyz_map
  assert smiles_to_xyz_map(original_source['smiles'],branch/'opt.xyz') is not None
  assert sha(owner['active_SP'])==owner['active_SP_sha256']
  exclusions.append(dict(key=original['key'],status='original_stationary_saddle_retained',source_status=str(BASE/original['key']/'status.json'),replacement=str(replacement)))
  tasks=[t for t in tasks if t['control']]+[rr['task']];case_paths[rr['task']['key']]=replacement.parent
  for path in (replacement,branch/'validation_status.json',branch/'convergence_recovery.json',branch.parent/'source.json',Path(owner['active_SP'])):evidence[str(path.relative_to(ROOT))]=sha(path)
 for task in tasks:
  case=case_paths.get(task['key'],BASE/task['key']);status=case/'status.json'
  if not status.exists() or json.loads(status.read_text()).get('status') in ('running','checking_worst_contact'):
   pending.append(task['key']);continue
  report=json.loads(status.read_text());expected='isolated_control_verified' if task['control'] else 'isolated_target_verified'
  check(task['key']+':terminal_verification',report['status']==expected)
  if report['status']!=expected:cases.append(dict(key=task['key'],status=report['status']));continue
  for path,digest in task['input_sha256'].items():check(task['key']+':source:'+path,sha(path)==digest)
  for path,digest in report['evidence_sha256'].items():
   check(task['key']+':evidence:'+path,sha(path)==digest);evidence[str(Path(path).relative_to(ROOT))]=digest
  work=case/'work';native_paths=list((work/'native_thermal').glob('*.json'));assert len(native_paths)==1
  p=native_paths[0];native=json.loads(p.read_text());mat=np.load(p.with_suffix('')/'hessian_cartesian.npy');atoms=read(work/'opt.xyz');nat=len(atoms)
  check(task['key']+':isolated_status',native['status']=='isolated_CDS_1e6_qualification_pending' and native['execution_derivatives']['qualification_only'] is True)
  check(task['key']+':identity',native['identity']['geometry_sha256']==sha(work/'opt.xyz')==task['input_sha256'][str(Path(task['source'])/'opt.xyz')] and native['identity']['protocol']==plan['protocol'])
  check(task['key']+':matrix',mat.shape==(3*nat,3*nat) and np.isfinite(mat).all() and abs(mat-mat.T).max()<=1e-6)
  check(task['key']+':stationarity_spin',native['stationary_minimum'] is True and native['converged'] is True and native['grid_response'] is True and 0<=native['gradient_max']<=.00045 and abs(native['smd_spin_diagnostics']['spin_contam'])<=.1)
  mol=gto.M(atom=list(zip(atoms.get_chemical_symbols(),(atoms.positions/.52917721067).tolist())),unit='Bohr',basis='def2-svpd' if task['charge']<0 else 'def2-svp',charge=task['charge'],spin=task['mult']-1,verbose=0)
  tensor=mat.reshape(nat,3,nat,3).transpose(0,2,1,3);freq=thermo.harmonic_analysis(mol,tensor,imaginary_freq=False)['freq_wavenumber']
  check(task['key']+':spectrum',len(freq)==3*nat-6 and np.isfinite(freq).all() and min(freq)>=-5 and np.max(abs(freq-np.asarray(native['frequencies_cm'])))<1e-7)
  for c in native['derivative_checks']:check(task['key']+':standard_FD:'+str(c),math.isfinite(c['relative_error']) and 0<=c['relative_error']<=.01)
  for cutoff in (25,50,100):
   text=(p.with_suffix('')/f'thermo_{cutoff}.log').read_text();match=re.search(r'G\(RRHO\) contrib\.\s+([\-\d.]+)\s+Eh',text);assert match
   check(task['key']+':thermal_'+str(cutoff),abs(float(match[1])*HA_EV-native['nuclear_by_cutoff_eV'][str(cutoff)])<1e-7)
  spin=-8.617333262145e-5*298.15*math.log(task['mult'])
  check(task['key']+':spin_thermal',abs(native['g_spin_partition_eV']-spin)<1e-8 and abs(native['g_thermal_total_eV']-native['nuclear_by_cutoff_eV']['50']-spin)<1e-8)
  coarse=np.load(case/'coarse_CDS_hessian.npy');i,j=np.unravel_index(np.argmax(abs(coarse-coarse.T)),coarse.shape)
  check(task['key']+':contact_identity',[int(i),int(j)]==report['worst_contact_indices'] and i!=j)
  observed=[]
  for column in sorted({int(i),int(j)}):
   for step in (.0005,.001):
    plus=np.load(case/f'gradient_{column}_{step}_1.npy');minus=np.load(case/f'gradient_{column}_{step}_-1.npy');numerical=(plus-minus)/(2*step);err=float(np.linalg.norm(numerical-mat[column])/np.linalg.norm(numerical))
    recorded=next(c['relative_error'] for c in report['worst_contact_checks'] if c['column']==column and c['step_Bohr']==step)
    check(task['key']+f':contact_{column}_{step}',np.isfinite(plus).all() and np.isfinite(minus).all() and math.isfinite(err) and err<=.01 and abs(err-recorded)<1e-12);observed.append(err)
  item=dict(key=task['key'],mult=task['mult'],status='reviewed',maximum_asymmetry=float(abs(mat-mat.T).max()),maximum_contact_relative_error=max(observed))
  if task['control']:
   baseline_path=next(Path(x) for x in task['input_sha256'] if '/native_thermal/' in x and x.endswith('.json'));baseline=json.loads(baseline_path.read_text());A=np.load(baseline_path.with_suffix('')/'hessian_cartesian.npy')
   rel=float(np.linalg.norm(A-mat)/np.linalg.norm(A));maximum=float(abs(A-mat).max());thermal=max(abs(baseline['nuclear_by_cutoff_eV'][str(c)]-native['nuclear_by_cutoff_eV'][str(c)]) for c in (25,50,100))
   check(task['key']+':matrix_thermal_replay',all(math.isfinite(v) and 0<=v<=1e-6 for v in (rel,maximum,thermal)))
   proof={str(status.relative_to(ROOT)):sha(status),**{str(Path(x).relative_to(ROOT)):h for x,h in report['evidence_sha256'].items()},**{str(Path(x).relative_to(ROOT)):h for x,h in task['input_sha256'].items()}}
   controls.append(dict(mult=task['mult'],native_gates_passed=True,relative_matrix_error=rel,maximum_matrix_difference=maximum,maximum_thermal_difference_eV=thermal,evidence_sha256=proof))
  evidence[str(status.relative_to(ROOT))]=sha(status);cases.append(item)
 failed=[c for c in checks if not c['passed']]
 result=dict(status='pending_cases' if pending else ('independent_review_failed' if failed else 'independent_review_passed'),spectrum_replay_threads=2,spectrum_replay_coordinate_unit='native Bohr conversion',checks=len(checks),failed_checks=len(failed),pending=pending,cases=cases,retained_original_exclusions=exclusions,production_admission=False,finished=time.time())
 suffix='_replacement' if a.replacement_case else '';atomic_write_json(BASE/('independent_review'+suffix+'.json'),result);atomic_write_json(BASE/('independent_checks'+suffix+'.json'),checks);print(json.dumps(result,indent=2))
 if a.seal:
  if pending or failed or len(controls)!=2 or {c['mult'] for c in controls}!={1,2}:raise RuntimeError('All cases and independent gates must pass before sealing')
  review_path=BASE/('independent_review'+suffix+'.json');check_path=BASE/('independent_checks'+suffix+'.json')
  auditor=BASE/'producer_snapshots'/('review_'+sha(__file__)+'.py')
  if not auditor.exists():auditor.write_bytes(Path(__file__).read_bytes())
  immutable_review=BASE/'producer_snapshots'/('review_result_'+sha(review_path)+'.json');immutable_checks=BASE/'producer_snapshots'/('review_checks_'+sha(check_path)+'.json')
  if not immutable_review.exists():immutable_review.write_bytes(review_path.read_bytes())
  if not immutable_checks.exists():immutable_checks.write_bytes(check_path.read_bytes())
  for path in (immutable_review,immutable_checks,auditor):evidence[str(path.relative_to(ROOT))]=sha(path)
  certificate=dict(schema=1,status='execution_derivatives_qualified',protocol=plan['protocol'],software={'pyscf':'2.14.0','gpu4pyscf':'1.8.1'},cds_step_Bohr=1e-6,library_default_cds_step_Bohr=1e-4,scientific_model_changed=False,controls=controls,worst_contact_validation=dict(steps_Bohr=[.0005,.001],relative_acceptance=.01,symmetry_acceptance=1e-6),qualification_review=str(immutable_review.relative_to(ROOT)),qualification_evidence_sha256=evidence,target_native_gates_passed=True,retained_original_exclusions=exclusions,created=time.time())
  certificate['content_sha256']=hashlib.sha256(json.dumps(certificate,sort_keys=True,separators=(',',':')).encode()).hexdigest();path=ROOT/'config/native_cds_step_1e6_validation.json'
  if path.exists():raise RuntimeError('Preserve existing certificate; never overwrite')
  atomic_write_json(path,certificate);print('Sealed',path)
 elif failed:raise SystemExit(1)
if __name__=='__main__':main()
