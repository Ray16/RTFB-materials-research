"""Isolated smaller-step CDS curvature replay; never publish production records."""
import argparse,hashlib,json,os,shutil,socket,time,traceback
from pathlib import Path
import numpy as np
from redox.core.common import ROOT,DFT
from redox.qm import native_thermal as N
from redox.validation.spins import atomic_json

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--state',required=True);ap.add_argument('--cpus',required=True);ap.add_argument('--control',action='store_true');a=ap.parse_args()
 assert os.getenv('CUDA_VISIBLE_DEVICES') and sorted(os.sched_getaffinity(0))==list(map(int,a.cpus.split(',')))
 sd=DFT/a.id/a.state;raw=json.loads((sd/'result.json').read_text());q,m=raw['charge'],raw['mult'];source=dict(geometry_sha256=sha(sd/'opt.xyz'),raw_sha256=sha(sd/'result.json'))
 out=Path(__file__).resolve().parent/'cds_qualification'/(a.id+'__'+a.state);out.mkdir(parents=True);(out/'producer_source.py').write_bytes(Path(__file__).read_bytes());work=out/'work';work.mkdir()
 for name in ['opt.xyz','result.json']:shutil.copy2(sd/name,work/name)
 baseline=N.load_native_thermal(sd,q,m) if a.control else None
 if a.control:assert baseline is not None
 report=dict(status='running',id=a.id,state=a.state,host=socket.gethostname(),pid=os.getpid(),process_start=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],started=time.time(),source=source,cds_internal_step_Bohr=1e-5,original_library_cds_step_Bohr=1e-4,scientific_model_changed=False,production_modified=False,production_admission=False,control=a.control)
 def save():atomic_json(out/'status.json',report)
 save()
 import gpu4pyscf.solvent.hessian.smd as H
 from gpu4pyscf.solvent.grad import smd as G
 original=H.get_cds
 def fine_cds(smdobj):
  mol=smdobj.mol.copy();tmp=smdobj.copy();coordinates=mol.atom_coords(unit='B');matrix=np.empty((mol.natm,mol.natm,3,3));step=1e-5
  for ia in range(mol.natm):
   for axis in range(3):
    grads=[]
    for sign in [-1,1]:
     x=coordinates.copy();x[ia,axis]+=sign*step;mol.set_geom_(x,unit='B');tmp.reset(mol);grads.append(np.asarray(G.get_cds(tmp)).copy())
    matrix[ia,:,axis]=(grads[1]-grads[0])/(2*step)
  return matrix
 H.get_cds=fine_cds
 try:
  _,thermal=N.ensure_native_thermal(a.id,a.state,state_dir=work)
  path,_=N.cache_path(work,q,m);mat=np.load(path.with_suffix('')/'hessian_cartesian.npy')
  report.update(native_gates_passed=True,maximum_asymmetry=thermal['maximum_asymmetry'],gradient_max=thermal['gradient_max'],minimum_frequency_cm=min(thermal['frequencies_cm']),derivative_checks=thermal['derivative_checks'],thermal_eV=thermal['g_thermal_total_eV'])
  if a.control:
   bp,_=N.cache_path(sd,q,m);B=np.load(bp.with_suffix('')/'hessian_cartesian.npy');report.update(relative_full_matrix_error=float(np.linalg.norm(mat-B)/np.linalg.norm(B)),maximum_full_matrix_error=float(abs(mat-B).max()),maximum_cutoff_thermal_difference_eV=max(abs(thermal['nuclear_by_cutoff_eV'][str(k)]-baseline['nuclear_by_cutoff_eV'][str(k)]) for k in [25,50,100]))
   assert report['relative_full_matrix_error']<1e-6 and report['maximum_full_matrix_error']<1e-6 and report['maximum_cutoff_thermal_difference_eV']<1e-6
  else:
   # Probe the actual contact that made the default CDS Hessian asymmetric,
   # beyond the generic native O/anchor checks. Keep both original FD steps.
   from ase.io import read
   from pyscf import gto
   from redox.qm.dft import _build_smd_mf,_ecp_for,_free_gpu_pool
   atoms=read(work/'opt.xyz');symbols=atoms.get_chemical_symbols();coords=atoms.positions/.52917721067
   diagnostic=Path(__file__).resolve().parent/'cds_convergence'/(a.id+'__'+a.state)/'cds_hessian_step_1e-04.npy'
   coarse=np.load(diagnostic);asym=abs(coarse-coarse.T);i,j=np.unravel_index(np.argmax(asym),asym.shape)
   report.update(worst_contact_indices=[int(i),int(j)],worst_contact_checks=[],coarse_CDS_sha256=sha(diagnostic));save()
   basis=N.NATIVE_THERMAL['anion_basis'] if q<0 else N.NATIVE_THERMAL['basis']
   for column in sorted({int(i),int(j)}):
    for step in (.0005,.001):
     gradients=[]
     for sign in [-1,1]:
      x=coords.copy();x.flat[column]+=sign*step
      mol=gto.M(atom=list(zip(symbols,x.tolist())),unit='Bohr',basis=basis,ecp=_ecp_for(symbols,basis),charge=q,spin=m-1,verbose=0,max_memory=6000)
      mf=_build_smd_mf(mol,'r2scan','acetonitrile','gpu',disp='d4');mf.grids.level=3;mf.conv_tol=1e-12;mf.conv_tol_grad=1e-8;mf.max_cycle=200;mf.kernel()
      assert mf.converged
      grad=mf.nuc_grad_method();grad.grid_response=True;value=grad.kernel();gradients.append(np.asarray(value.get() if hasattr(value,'get') else value).ravel().copy())
      del mf,grad,value;_free_gpu_pool()
     numerical=(gradients[1]-gradients[0])/(2*step);error=float(np.linalg.norm(numerical-mat[column])/np.linalg.norm(numerical))
     report['worst_contact_checks'].append(dict(column=column,step_Bohr=step,relative_error=error));save()
     if error>.01:raise RuntimeError('Worst-contact finite-gradient check failed unchanged1% gate')
  # Quarantine the isolated record explicitly even though original gates passed.
  r=json.loads(path.read_text());r['status']='isolated_CDS_derivative_qualification';r['execution_derivatives']=dict(cds_step_Bohr=1e-5,qualification_only=True,production_admission=False);atomic_json(path,r)
  assert N.load_native_thermal(work,q,m) is None
  report.update(status='control_replay_verified' if a.control else 'isolated_native_gates_verified',evidence_sha256={str(p.relative_to(ROOT)):sha(p) for p in [path,path.with_suffix('')/'hessian_cartesian.npy',work/'opt.xyz']},finished=time.time(),source_unchanged=source==dict(geometry_sha256=sha(sd/'opt.xyz'),raw_sha256=sha(sd/'result.json')));save()
 except BaseException as exc:report.update(status='failed_preserved',error=repr(exc),traceback=traceback.format_exc(),finished=time.time());save();raise
 finally:H.get_cds=original
if __name__=='__main__':main()
