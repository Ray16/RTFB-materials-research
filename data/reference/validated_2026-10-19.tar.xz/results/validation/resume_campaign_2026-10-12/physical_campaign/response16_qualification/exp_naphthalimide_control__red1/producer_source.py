"""Isolated exact-equation response16GiB replay; immutable24GiB certificate untouched."""
import argparse,hashlib,json,os,shutil,socket,time,traceback
from pathlib import Path
import numpy as np
from redox.core.common import ROOT,DFT
from redox.qm import native_thermal as N,hessian_memory as M
from redox.validation.spins import atomic_json

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--id',required=True);ap.add_argument('--state',required=True);ap.add_argument('--cpus',required=True);ap.add_argument('--control',action='store_true');a=ap.parse_args()
 assert os.getenv('CUDA_VISIBLE_DEVICES') and sorted(os.sched_getaffinity(0))==list(map(int,a.cpus.split(',')))
 sd=DFT/a.id/a.state;raw=json.loads((sd/'result.json').read_text());q,m=raw['charge'],raw['mult'];source=dict(geometry_sha256=sha(sd/'opt.xyz'),raw_sha256=sha(sd/'result.json'))
 out=Path(__file__).resolve().parent/'response16_qualification'/(a.id+'__'+a.state);out.mkdir(parents=True);(out/'producer_source.py').write_bytes(Path(__file__).read_bytes());work=out/'work';work.mkdir()
 for name in ['opt.xyz','result.json']:shutil.copy2(sd/name,work/name)
 baseline=N.load_native_thermal(sd,q,m) if a.control else None
 if a.control:assert baseline is not None
 report=dict(status='running',id=a.id,state=a.state,host=socket.gethostname(),pid=os.getpid(),process_start=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],started=time.time(),source=source,response_cap_GiB=16,integral_cap_GiB=6,scientific_model_changed=False,production_modified=False,production_admission=False,control=a.control,large_allocations=[])
 def save():atomic_json(out/'status.json',report)
 save();original=M.stage_budget_bytes
 def variant(budget,module,function):
  return (16 if module=='gpu4pyscf.df.hessian.uhf' and function=='_get_veff' else 6)*1024**3
 M.stage_budget_bytes=variant
 import cupy as cp
 allocations={name:getattr(cp,name) for name in ['zeros','empty']}
 def capture(name):
  def allocated(shape,*args,**kwargs):
   size=int(np.prod(shape))*np.dtype(kwargs.get('dtype',np.float64)).itemsize
   if size>500*1024**2:
    item=dict(function=name,shape=[int(v) for v in shape] if isinstance(shape,(list,tuple)) else int(shape),bytes=size,device_free_bytes=int(cp.cuda.runtime.memGetInfo()[0]),pool_used_bytes=int(cp.get_default_memory_pool().used_bytes()),pool_total_bytes=int(cp.get_default_memory_pool().total_bytes()));report['large_allocations'].append(item);save()
   return allocations[name](shape,*args,**kwargs)
  return allocated
 for name in allocations:setattr(cp,name,capture(name))
 try:
  _,thermal=N.ensure_native_thermal(a.id,a.state,state_dir=work,memory_cap_gib=24,qualification=True)
  path,_=N.cache_path(work,q,m);mat=np.load(path.with_suffix('')/'hessian_cartesian.npy')
  report.update(native_gates_passed=True,maximum_asymmetry=thermal['maximum_asymmetry'],gradient_max=thermal['gradient_max'],minimum_frequency_cm=min(thermal['frequencies_cm']),derivative_checks=thermal['derivative_checks'],thermal_eV=thermal['g_thermal_total_eV'])
  if a.control:
   bp,_=N.cache_path(sd,q,m);B=np.load(bp.with_suffix('')/'hessian_cartesian.npy');report.update(relative_full_matrix_error=float(np.linalg.norm(mat-B)/np.linalg.norm(B)),maximum_full_matrix_error=float(abs(mat-B).max()),maximum_cutoff_thermal_difference_eV=max(abs(thermal['nuclear_by_cutoff_eV'][str(k)]-baseline['nuclear_by_cutoff_eV'][str(k)]) for k in [25,50,100]))
   assert report['relative_full_matrix_error']<1e-6 and report['maximum_full_matrix_error']<1e-6 and report['maximum_cutoff_thermal_difference_eV']<1e-6
  r=json.loads(path.read_text());r['execution_memory'].update(cap_GiB=16,allocation_policy='six-GiB integral batches; sixteen-GiB unrestricted response workspace',qualification_only=True);atomic_json(path,r)
  assert N.load_native_thermal(work,q,m) is None
  report.update(status='control_replay_verified' if a.control else 'isolated_native_gates_verified',evidence_sha256={str(p.relative_to(ROOT)):sha(p) for p in [path,path.with_suffix('')/'hessian_cartesian.npy',work/'opt.xyz']},finished=time.time(),source_unchanged=source==dict(geometry_sha256=sha(sd/'opt.xyz'),raw_sha256=sha(sd/'result.json')));save()
 except BaseException as exc:report.update(status='failed_preserved',error=repr(exc),traceback=traceback.format_exc(),finished=time.time());save();raise
 finally:
  M.stage_budget_bytes=original
  for name,func in allocations.items():setattr(cp,name,func)
if __name__=='__main__':main()
